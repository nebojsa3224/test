import * as names from 'names.js';

function main() {
    
    startApplication("notepad++");
    type(waitForObject(names.aBCPane_2), "hhkjh");
    mouseClick(waitForObjectItem(names.new1NotepadMenuBar, "Edit"));
    mouseClick(waitForObjectItem(names.editMenuItem, "Select All"));
    mouseClick(waitForObjectItem(names.new1NotepadMenuBar, "Edit"));
    mouseClick(waitForObjectItem(names.editMenuItem, "Copy"));
    startApplication("filesystemexplorer");
    mouseClick(waitForImage("image_14"));
    mouseClick(waitForObject(names.pasteMenuItem));
    snooze(4);
}
