import * as names from 'names.js';

function main()
{
    startApplication("filesystemexplorer");
    mouseClick(waitForObject(names.checkBox));
    mouseClick(waitForImage("image_9"));
    snooze(6);
    mouseClick(waitForImage("image_10"));
    snooze(6);
    test.imagePresent("image_13",{
    maxScale:101,
        threshold:98.227
    });
    snooze(2);
    mouseClick(waitForImage("image_4",{
    maxScale:101,
    	threshold:78.227
    }));
    snooze(2);
    mouseClick(waitForObject(names.toggleLineNumbersOFFMenuItem));
    snooze(2);
    test.imageNotPresent("image_13",{
    maxScale:101,
        threshold:98.227
    });
    
}
