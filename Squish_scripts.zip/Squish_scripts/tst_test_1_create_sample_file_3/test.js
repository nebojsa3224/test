import * as names from 'names.js';

function main() {
    startApplication("notepad++");
    type(waitForObject(names.aBCPane_2), "123");
    type(waitForObject(names.aBCPane_2), "<Return>");
    type(waitForObject(names.aBCPane_2), "234");
    type(waitForObject(names.aBCPane_2), "<Return>");
    mouseClick(waitForObjectItem(names.new1NotepadMenuBar, "File"));
    mouseClick(waitForObjectItem(names.fileMenuItem, "Save As..."));
    chooseFile("C:\\Users\\NeshBozic\\1_TestOct18\\1_test_file.txt");
    mouseDrag(waitForObject(names.cUsersNeshBozic1TestOct181TestFileTxtNotepadWindow), 1675, 11, -565, 319);
}
