import * as names from 'names.js';

function main() {
    
    startApplication("filesystemexplorer");
    mouseClick(waitForObject(names.checkBox));
    mouseClick(waitForImage("image_9"));
    snooze(6);
    mouseClick(waitForImage("image_10"));
    snooze(6);
    type(waitForObject(names.edit), "<Return>");
    type(waitForObject(names.edit), "abc");
    snooze(5);
  
}
