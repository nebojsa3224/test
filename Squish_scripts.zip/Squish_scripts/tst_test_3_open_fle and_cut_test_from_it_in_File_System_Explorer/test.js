import * as names from 'names.js';

function main()
{
    startApplication("filesystemexplorer");
    mouseClick(waitForObject(names.checkBox));
    mouseClick(waitForImage("image_9"));
    snooze(6);
    mouseClick(waitForImage("image_10"));
    snooze(6);
    type(waitForObject(names.edit), "<Return>");
    dragAndDrop(waitForObject(names.edit), 16, 31, names.pane_2, 418, 32);
    mouseClick(waitForObject(names.group));
    mouseClick(waitForObject(names.cutMenuItem));
    mouseClick(waitForImage("image_1"));
    mouseClick(waitForImage("image_11"));    
    snooze(5);
    
}
